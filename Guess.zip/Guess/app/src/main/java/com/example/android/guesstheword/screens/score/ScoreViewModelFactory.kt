package com.example.android.guesstheword.screens.score

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

/**
 * Copy over ScoreViewModelFactory - have it also take in a constructor parameter called finalScore
 *
 */
class ScoreViewModelFactory(private val finalScore: Int) : ViewModelProvider.Factory {

    /**
     *  construct an instance of ScoreViewModel, passing in finalScore
     */
    //this method is called when the ViewModel is created, returns a ViewModel
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ScoreViewModel::class.java)) {
            return ScoreViewModel(finalScore) as T // Construct and return the ScoreViewModel
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}